package ssii.pai1.integrity;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IntegrityApplication {

	public static void main(String[] args) {
		SpringApplication.run(IntegrityApplication.class, args);
	}

}
