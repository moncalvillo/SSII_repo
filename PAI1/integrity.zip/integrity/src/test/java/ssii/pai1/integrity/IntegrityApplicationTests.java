package ssii.pai1.integrity;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IntegrityApplicationTests {

	@Test
	void contextLoads() {
	}

}
